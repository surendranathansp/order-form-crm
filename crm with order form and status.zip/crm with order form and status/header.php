<div class="header navbar navbar-inverse ">
  <div class="navbar-inner">
    <div class="header-seperation text-center">
      <ul class="nav pull-left notifcation-center" id="main-menu-toggle-wrapper" style="display:none">
        <li class="dropdown"> <a id="main-menu-toggle" href="#main-menu"  class="" >
          <div class="iconset top-menu-toggle-white"></div>
          </a> </li>
      </ul>
      <h2>
      <a href="dashboard.php" class="text-white"><strong>Main menu </strong></a>
      </h2>
    </div>
    <div class="header-quick-nav" >
      <div class="ml-2 pull-left" style="padding-top: 0.5em;padding-left: 1em">
        
        <h4>
        <a href="./admin/dashboard.php" class="text-reset"><strong>Kamaraj Stickers</strong></a>
        </h4>
        <ul class="nav quick-section">
          
        </ul>
      </div>
      <div class="pull-right">
        <ul class="nav quick-section ">
          <li class="quicklinks"> <a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
            <div class="iconset top-settings-dark "></div>
            </a>
            <ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
              <li class="divider"></li>
              <li><a href="logout.php"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Log Out</a></li>
            </ul>
          </li>
         
        </ul>
      </div>
      <!-- END CHAT TOGGLER -->
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>
  <!-- END TOP NAVIGATION BAR -->
</div>
<!-- END HEADER -->